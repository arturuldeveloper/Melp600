XML-RPC server accepts POST requests only.
<!-- WP Optimize page cache - https://teamupdraft.com/wp-optimize/ - page NOT cached -->
